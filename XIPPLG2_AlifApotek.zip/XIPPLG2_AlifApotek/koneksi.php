<?php
$host = 'localhost';
$username = 'username';
$password = 'password';
$database = 'apotek_alif';

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}
?>