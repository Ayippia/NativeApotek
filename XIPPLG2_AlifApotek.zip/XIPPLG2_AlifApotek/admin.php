<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="XIPPLG2/styles.css">
    <title>Halaman Admin Aplikasi Web Apotik</title>
</head>
<body>
    <h1>Dashboard Admin</h1>

    <!-- Form Tambah Pengguna -->
    <h2>Tambah Pengguna</h2>
    <form method="post">
        <input type="text" name="username" placeholder="Username">
        <input type="password" name="password" placeholder="Password">
        <button type="submit" name="tambah_pengguna">Tambah Pengguna</button>
    </form>

    <!-- Form Edit Pengguna -->
    <h2>Edit Pengguna</h2>
    <form method="post">
        <input type="hidden" name="user_id" value="user_id_to_edit">
        <input type="text" name="new_username" placeholder="Username Baru">
        <input type="password" name="new_password" placeholder="Password Baru">
        <button type="submit" name="edit_pengguna">Edit Pengguna</button>
    </form>

    <!-- Daftar Pengguna -->
    <h2>Daftar Pengguna</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Aksi</th>
        </tr>
        <tr>
            <td>user_id</td>
            <td>username</td>
            <td>
                <a href="?hapus_pengguna=user_id">Hapus</a>
                <a href="?edit_pengguna=user_id">Edit</a>
            </td>
        </tr>
        <!-- Tampilkan daftar pengguna dari database -->
    </table>

    <!-- Form Tambah Pegawai -->
    <h2>Tambah Pegawai</h2>
    <form method="post">
        <input type="text" name="nama_pegawai" placeholder="Nama Pegawai">
        <input type="text" name="alamat" placeholder="Alamat Pegawai">
        <input type="text" name="telepon" placeholder="Telepon Pegawai">
        <button type="submit" name="tambah_pegawai">Tambah Pegawai</button>
    </form>

    <!-- Form Edit Pegawai -->
    <h2>Edit Pegawai</h2>
    <form method="post">
        <input type="hidden" name="pegawai_id" value="pegawai_id_to_edit">
        <input type="text" name="new_nama" placeholder="Nama Pegawai Baru">
        <input type="text" name="new_alamat" placeholder="Alamat Pegawai Baru">
        <input type="text" name="new_telepon" placeholder="Telepon Pegawai Baru">
        <button type="submit" name="edit_pegawai">Edit Pegawai</button>
    </form>

    <!-- Daftar Pegawai -->
    <h2>Daftar Pegawai</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Nama Pegawai</th>
            <th>Alamat</th>
            <th>Telepon</th>
            <th>Aksi</th>
        </tr>
        <tr>
            <td>pegawai_id</td>
            <td>nama_pegawai</td>
            <td>alamat_pegawai</td>
            <td>telepon_pegawai</td>
            <td>
                <a href="?hapus_pegawai=pegawai_id">Hapus</a>
                <a href="?edit_pegawai=pegawai_id">Edit</a>
            </td>
        </tr>
        <!-- Tampilkan daftar pegawai dari database -->
    </table>

    <!-- Form Tambah Stok Obat-Obatan -->
    <h2>Tambah Stok Obat-Obatan</h2>
    <form method="post">
        <input type="text" name="nama_obat" placeholder="Nama Obat">
        <input type="number" name="jumlah" placeholder="Jumlah">
        <button type="submit" name="tambah_stok_obat">Tambah Stok Obat-Obatan</button>
    </form>

    <!-- Form Edit Stok Obat-Obatan -->
    <h2>Edit Stok Obat-Obatan</h2>
    <form method="post">
        <input type="hidden" name="obat_id" value="obat_id_to_edit">
        <input type="text" name="new_nama_obat" placeholder="Nama Obat Baru">
        <input type="number" name="new_jumlah" placeholder="Jumlah Baru">
        <button type="submit" name="edit_stok_obat">Edit Stok Obat-Obatan</button>
    </form>

    <!-- Daftar Stok Obat-Obatan -->
    <h2>Daftar Stok Obat-Obatan</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Nama Obat</th>
            <th>Jumlah</th>
            <th>Aksi</th>
        </tr>
        <tr>
            <td>obat_id</td>
            <td>nama_obat</td>
            <td>jumlah_obat</td>
            <td>
                <a href="?hapus_obat=obat_id">Hapus</a>
                <a href="?edit_obat=obat_id">Edit</a>
            </td>
        </tr>
        <!-- Tampilkan daftar stok obat-obatan dari database -->
    </table>

    <script src="js/bootstrap.min.js"></script>
</body>
</html>
