<?php
// Include koneksi.php
include 'koneksi.php';

// Operasi CRUD Pengguna
if (isset($_POST['tambah_pengguna'])) {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $query = "INSERT INTO users (username, password) VALUES ('$username', '$password')";
    mysqli_query($conn, $query);
    // Tambahkan pesan sukses atau pesan kesalahan
}

if (isset($_POST['edit_pengguna'])) {
    $user_id = $_POST['user_id'];
    $new_username = $_POST['new_username'];
    $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

    $query = "UPDATE users SET username='$new_username', password='$new_password' WHERE id=$user_id";
    mysqli_query($conn, $query);
    // Tambahkan pesan sukses atau pesan kesalahan
}

if (isset($_GET['hapus_pengguna'])) {
    $user_id = $_GET['hapus_pengguna'];

    $query = "DELETE FROM users WHERE id=$user_id";
    mysqli_query($conn, $query);
    // Tambahkan pesan sukses atau pesan kesalahan
}

// Operasi SELECT Pengguna
$query = "SELECT * FROM users";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['username'] . "</td>";
        echo "<td><a href='?hapus_pengguna=" . $row['id'] . "'>Hapus</a></td>";
        echo "<td><a href='?edit_pengguna=" . $row['id'] . "'>Edit</a></td>";
        echo "</tr>";
    }
}
?>
