<?php
// Include koneksi.php
include 'koneksi.php';

// Operasi CRUD Pegawai
if (isset($_POST['tambah_pegawai'])) {
    $nama_pegawai = $_POST['nama_pegawai'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];

    $query = "INSERT INTO pegawai (nama_pegawai, alamat, telepon) VALUES ('$nama_pegawai', '$alamat', '$telepon')";
    mysqli_query($conn, $query);
    // Tambahkan pesan sukses atau pesan kesalahan
}

if (isset($_POST['edit_pegawai'])) {
    $pegawai_id = $_POST['pegawai_id'];
    $new_nama = $_POST['new_nama'];
    $new_alamat = $_POST['new_alamat'];
    $new_telepon = $_POST['new_telepon'];

    $query = "UPDATE pegawai SET nama_pegawai='$new_nama', alamat='$new_alamat', telepon='$new_telepon' WHERE id=$pegawai_id";
    mysqli_query($conn, $query);
    // Tambahkan pesan sukses atau pesan kesalahan
}

if (isset($_GET['hapus_pegawai'])) {
    $pegawai_id = $_GET['hapus_pegawai'];

    $query = "DELETE FROM pegawai WHERE id=$pegawai_id";
    mysqli_query($conn, $query);
    // Tambahkan pesan sukses atau pesan kesalahan
}

// Operasi SELECT Pegawai
$query = "SELECT * FROM pegawai";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['nama_pegawai'] . "</td>";
        echo "<td><a href='?hapus_pegawai=" . $row['id'] . "'>Hapus</a></td>";
        echo "<td><a href='?edit_pegawai=" . $row['id'] . "'>Edit</a></td>";
        echo "</tr>";
    }
}
?>
