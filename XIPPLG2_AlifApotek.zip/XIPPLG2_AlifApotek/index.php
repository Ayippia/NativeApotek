<!DOCTYPE html>
<html>
<head>
    <title>Halaman Depan Aplikasi Web Apotik</title>
</head>
<body>
    <h1>Selamat datang di Aplikasi Web Apotik</h1>
    <p><a href="admin.php">Masuk ke Halaman Admin</a></p>
</body>
</html>
