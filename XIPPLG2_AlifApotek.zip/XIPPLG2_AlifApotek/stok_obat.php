<?php
// Include koneksi.php
include 'koneksi.php';

// Operasi CRUD Stok Obat-Obatan
if (isset($_POST['tambah_stok_obat'])) {
    $nama_obat = $_POST['nama_obat'];
    $jumlah = $_POST['jumlah'];

    $query = "INSERT INTO stok_obat (nama_obat, jumlah) VALUES ('$nama_obat', $jumlah)";
    mysqli_query($conn, $query);
    // Tambahkan pesan sukses atau pesan kesalahan
}

if (isset($_POST['edit_stok_obat'])) {
    $obat_id = $_POST['obat_id'];
    $new_nama_obat = $_POST['new_nama_obat'];
    $new_jumlah = $_POST['new_jumlah'];

    $query = "UPDATE stok_obat SET nama_obat='$new_nama_obat', jumlah=$new_jumlah WHERE id=$obat_id";
    mysqli_query($conn, $query);
    // Tambahkan pesan sukses atau pesan kesalahan
}

if (isset($_GET['hapus_obat'])) {
    $obat_id = $_GET['hapus_obat'];

    $query = "DELETE FROM stok_obat WHERE id=$obat_id";
    mysqli_query($conn, $query);
    // Tambahkan pesan sukses atau pesan kesalahan
}

// Operasi SELECT Stok Obat-Obatan
$query = "SELECT * FROM stok_obat";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['nama_obat'] . "</td>";
        echo "<td>" . $row['jumlah'] . "</td>";
        echo "<td><a href='?hapus_obat=" . $row['id'] . "'>Hapus</a></td>";
        echo "<td><a href='?edit_obat=" . $row['id'] . "'>Edit</a></td>";
        echo "</tr>";
    }
}
?>
